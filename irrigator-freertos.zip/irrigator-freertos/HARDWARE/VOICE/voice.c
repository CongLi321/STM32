#include "pump.h"
#include "FreeRTOS.h"
#include "voice.h"
#include "task.h"

#if EN_USART5_RX //如果使能了串口5接收
//串口1中断服务程序
//注意,读取USARTx->SR能避免莫名其妙的错误   	z
u8 USART5_RX_BUF[USART5_REC_LEN]; //接收缓冲,最大USART_REC_LEN个字节.
//接收状态
// bit15，	接收完成标志
// bit14，	接收到0x0d
// bit13~0，	接收到的有效字节数目
u16 USART5_RX_STA = 0; //接收状态标记
int USART_PRINTF_FLAG = 1;

//串口初始化
void uart5_init(u32 bound)
{
    // GPIO端口设置
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD, ENABLE); //使能USART5，GPIOA时钟
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5, ENABLE);

    // USART1_TX   GPIOA.2
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12; // PA.2
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; //复用推挽输出
    GPIO_Init(GPIOC, &GPIO_InitStructure);          //初始化GPIOA.2

    // USART1_RX	  GPIOA.3初始化
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;             // PA3
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; //浮空输入
    GPIO_Init(GPIOD, &GPIO_InitStructure);                //初始化GPIOA.3

    // Usart1 NVIC 配置
    NVIC_InitStructure.NVIC_IRQChannel = UART5_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2; //抢占优先级1 //优先级也要改哦
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;        //子优先级3
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;           // IRQ通道使能
    NVIC_Init(&NVIC_InitStructure);                           //根据指定的参数初始化VIC寄存器

    // USART 初始化设置

    USART_InitStructure.USART_BaudRate = bound;                                     //串口波特率
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;                     //字长为8位数据格式
    USART_InitStructure.USART_StopBits = USART_StopBits_1;                          //一个停止位
    USART_InitStructure.USART_Parity = USART_Parity_No;                             //无奇偶校验位
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; //无硬件数据流控制
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;                 //收发模式

    USART_Init(UART5, &USART_InitStructure);      //初始化串口5
    USART_ITConfig(UART5, USART_IT_RXNE, ENABLE); //开启串口接受中断
    USART_Cmd(UART5, ENABLE);                     //使能串口5
}

//串口5中断服务程序
void USART5_IRQHandler(void)
{
    u8 Res;
    USART_PRINTF_FLAG = 2;
#if SYSTEM_SUPPORT_OS //如果SYSTEM_SUPPORT_OS为真，则需要支持OS.
                      // OSIntEnter();
#endif
    if (USART_GetITStatus(UART5, USART_IT_RXNE) != RESET) //接收中断(接收到的数据必须是0x0d 0x0a结尾)
    {
        Res = USART_ReceiveData(UART5); //读取接收到的数据

        if ((USART5_RX_STA & 0x8000) == 0) //接收未完成
        {
            if (USART5_RX_STA & 0x4000) //接收到了0x0d
            {
                if (Res != 0x0a)
                    USART5_RX_STA = 0; //接收错误,重新开始
                else
                    USART5_RX_STA |= 0x8000; //接收完成了
            }
            else //还没收到0X0D
            {
                if (Res == 0x0d)
                    USART5_RX_STA |= 0x4000;
                else
                {
                    USART5_RX_BUF[USART5_RX_STA & 0X3FFF] = Res;
                    USART5_RX_STA++;
                    if (USART5_RX_STA > (USART5_REC_LEN - 1))
                        USART5_RX_STA = 0; //接收数据错误,重新开始接收
                }
            }
        }
    }
#if SYSTEM_SUPPORT_OS //如果SYSTEM_SUPPORT_OS为真，则需要支持OS.
                      // OSIntExit();
#endif
}
#endif

u8 SOUND[5] = {0xAA, 0x13, 0x01, 0x1E, 0xDC};
u8 SOUND0[6] = {0xAA, 0x07, 0x02, 0x00, 0x01, 0xB4}; // 0
u8 SOUND1[6] = {0xAA, 0x07, 0x02, 0x00, 0x02, 0xB5}; // 1
u8 SOUND2[6] = {0xAA, 0x07, 0x02, 0x00, 0x03, 0xB6}; // 2
u8 SOUND3[6] = {0xAA, 0x07, 0x02, 0x00, 0x04, 0xB7}; // 3
u8 SOUND4[6] = {0xAA, 0x07, 0x02, 0x00, 0x05, 0xB8}; // 4
u8 SOUND5[6] = {0xAA, 0x07, 0x02, 0x00, 0x06, 0xB9}; // 5
u8 SOUND6[6] = {0xAA, 0x07, 0x02, 0x00, 0x07, 0xBA}; // 6
u8 SOUND7[6] = {0xAA, 0x07, 0x02, 0x00, 0x08, 0xBB}; // 7
u8 SOUND8[6] = {0xAA, 0x07, 0x02, 0x00, 0x09, 0xBC}; // 8
u8 SOUND9[6] = {0xAA, 0x07, 0x02, 0x00, 0x0A, 0xBD}; // 9
u8 SOUND_ELECT[6] = {0xAA, 0x07, 0x02, 0x00, 0x0F, 0xC2}; //本次用电

u8 SOUND_DOT[6] = {0xAA, 0x07, 0x02, 0x00, 0x10, 0xC3};
u8 SOUND_YUAN[6] = {0xAA, 0x07, 0x02, 0x00, 0x0C, 0xBF};    //元
u8 SOUND_BAY[6] = {0xAA, 0x07, 0x02, 0x00, 0x0D, 0xC0};     //欢迎您
u8 SOUND_HELLO[6] = {0xAA, 0x07, 0x02, 0x00, 0x0E, 0xC1};   //你好
u8 SOUND_OPEN[6] = {0xAA, 0x07, 0x02, 0x00, 0x11, 0xC4};    //水泵开启中
u8 SOUND_BALANCE[6] = {0xAA, 0x07, 0x02, 0x00, 0x12, 0xC5}; //余额

u8 SOUND_TEST[6] = {0xAA, 0x07, 0x02, 0x00, 0x0A, 0xBD}; //余额

//语音command
void sound_command(u8 *pucStr, u8 ulNum)
{
    u8 i;
    for (i = 0; i < ulNum; i++)
    {
        while (USART_GetFlagStatus(UART5, USART_FLAG_TC) == RESET)
            ;

        USART_SendData(UART5, *pucStr++);
        vTaskDelay(20);
    }
}

void sound_test(void)
{
	sound_command(SOUND_TEST,6);
}
//音量初始化设置
void sound_init()
{
	printf("sound_init\r\n");
    uart5_init(9600);
    sound_command(SOUND, 5);
}

//播放语音
void voice_play(u8 *pucStr)
{
    sound_command(pucStr, 6);
}

//播放单个数字
void play_StraightBet(int number)
{
    switch (number % 10)
    {
    case 0:
        voice_play(SOUND0);
        break;
    case 1:
        voice_play(SOUND1);
        break;
    case 2:
        voice_play(SOUND2);
        break;
    case 3:
        voice_play(SOUND3);
        break;
    case 4:
        voice_play(SOUND4);
        break;
    case 5:
        voice_play(SOUND5);
        break;
    case 6:
        voice_play(SOUND6);
        break;
    case 7:
        voice_play(SOUND7);
        break;
    case 8:
        voice_play(SOUND8);
        break;
    case 9:
        voice_play(SOUND9);
        break;
    }
}

//播放数字
int play_number(int number)
{
    if (number >= 999999)
        return -1;

    //十万位
    if (number / 100000)
    {
        play_StraightBet(number / 100000);
        vTaskDelay(400);
    }
    //万位
    if (number / 10000)
    {
        play_StraightBet(number / 10000);
        vTaskDelay(400);
    }
    //千位
    if (number / 1000)
    {
        play_StraightBet(number / 1000);
        vTaskDelay(400);
    }

    //百位
    if (number / 100)
    {
        play_StraightBet(number / 100);
        vTaskDelay(400);
    }

    //十位
    if (number / 10)
    {
        play_StraightBet(number / 10);
        vTaskDelay(400);
    }
    //个位
    play_StraightBet(0);
    vTaskDelay(400);

    return 0;
}

//本次用电
void sound_elect(u32 con)
{
    voice_play(SOUND_ELECT);
    vTaskDelay(1500);
    play_number(con/100);
    sound_dot();
    play_number(con%100);
    sound_yuan();
    vTaskDelay(500);
    sound_bay();
}

//元
void sound_yuan(void)
{
    voice_play(SOUND_YUAN);
}

//欢迎下次
void sound_bay(void)
{
    voice_play(SOUND_BAY);
}

//你好
void sound_hello(void)
{
    voice_play(SOUND_HELLO);
}

//开启中
void sound_open(void)
{
    voice_play(SOUND_OPEN);
}

//余额
void sound_balance(void)
{
    voice_play(SOUND_BALANCE);
}

void sound_dot(void)
{
    voice_play(SOUND_DOT);
}