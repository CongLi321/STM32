#ifndef __VOICE_H
#define __VOICE_H
#include "sys.h"

#define USART5_REC_LEN 200 //定义最大接收字节数 200
#define EN_USART5_RX 1     //使能（1）/禁止（0）串口1接收
typedef enum
{
    AUDIO_ITEM_0 = 0x01,
    AUDIO_ITEM_1 = 0x02,
    AUDIO_ITEM_2 = 0x03,
    AUDIO_ITEM_3 = 0x04,
    AUDIO_ITEM_4 = 0x05,
    AUDIO_ITEM_5 = 0x06,
    AUDIO_ITEM_6 = 0x07,
    AUDIO_ITEM_7 = 0x08,
    AUDIO_ITEM_8 = 0x09,
    AUDIO_ITEM_9 = 0x0A,
    AUDIO_ITEM_POINT = 0x0B,
    AUDIO_ITEM_YUAN = 0x0C,
    AUDIO_ITEM_WELECOM_AGAIN = 0x0D,
    AUDIO_ITEM_WELECOM = 0x0E,
    AUDIO_ITEM_ELECTRON = 0x0F,
    AUDIO_ITEM_PUMP_OPEN = 0x11,
    AUDIO_ITEM_BALANCE = 0x12,
} AUDIO_ITEM; 

void sound_command(u8 *pucStr, u8 ulNum); //语音command
void sound_init(void);                    //语音初始化
void voice_play(u8 *pucStr);              //语音播报
void play_StraightBet(int number);        //播放单个数字
int play_number(int number);              //播放数字
void sound_test(void);
//本次
void sound_elect(u32 con);

//元
void sound_yuan(void);

//欢迎下次
void sound_bay(void);

//你好
void sound_hello(void);

//开启中
void sound_open(void);

//余额
void sound_balance(void);

void sound_dot(void);
#endif
