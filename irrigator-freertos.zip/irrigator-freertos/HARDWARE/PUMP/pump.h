#ifndef __PUMP_H
#define __PUMP_H
#include "sys.h"

#define PUMP2 PCout(3)
#define PUMP3 PBout(6)
#define PUMP4 PBout(7)

void PUMP_Init(void); //???
void Open(void);     //???
void Close(void);    //???
#endif

typedef struct Type_Device_Context
{
   uint16_t SN[6];
   u8 pump_status;          //是否开井，0x01开,0x00关
   u32 elect_init_value;    //开井时电表数值
   u16 ic_id;               //用户卡号
   u32 remaining_amount;    //剩余金额（单位：分）
   u32 sum_water_use;       //累计用水
   u32 sum_electricity_use; //累计用电
   u16 region;              //区域号
   u8 billing_type;         //计费方式
   u16 pulse_constant;      //电脉冲常数
   u32 price;               //单价
   u16 seted;               //是否已经设置
} Device_Context;
extern Device_Context device_context;

void set_device_context(void);
void get_device_context(void);
