#include "im3331.h"
#include "FreeRTOS.h"
#include "task.h"
#include "sys.h"
#include "usart.h"
#include "delay.h"
u32 now_power;
//接收缓存区
u8 RX3_BUF[64]; //接收缓冲,最大64个字节.
//接收到的数据长度
u8 RX3_CNT = 0;

void USART3_IRQHandler(void)
{
    u8 res;

    if (USART_GetITStatus(USART3, USART_IT_RXNE) != RESET) //接收到数据
    {

        res = USART_ReceiveData(USART3); //读取接收到的数据
        if (RX3_CNT < 64)
        {
            RX3_BUF[RX3_CNT] = res; //记录接收到的值
            RX3_CNT++;              //接收数据增加1
        }
    }
}

void uart3_init(u32 bound)
{
    // GPIO端口设置
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); //使能USART1，GPIOA时钟
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);

    // USART1_TX   GPIOA.2
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10; // PA.2
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; //复用推挽输出
    GPIO_Init(GPIOB, &GPIO_InitStructure);          //初始化GPIOA.2

    // USART1_RX	  GPIOA.3初始化
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;            // PA3
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; //浮空输入
    GPIO_Init(GPIOB, &GPIO_InitStructure);                //初始化GPIOA.3

    // Usart1 NVIC 配置
    NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3; //抢占优先级1 //优先级也要改哦
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;        //子优先级3
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;           // IRQ通道使能
    NVIC_Init(&NVIC_InitStructure);                           //根据指定的参数初始化VIC寄存器

    // USART 初始化设置

    USART_InitStructure.USART_BaudRate = bound;                                     //串口波特率
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;                     //字长为8位数据格式
    USART_InitStructure.USART_StopBits = USART_StopBits_1;                          //一个停止位
    USART_InitStructure.USART_Parity = USART_Parity_No;                             //无奇偶校验位
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; //无硬件数据流控制
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;                 //收发模式

    USART_Init(USART3, &USART_InitStructure);      //初始化串口1
    USART_ITConfig(USART3, USART_IT_RXNE, ENABLE); //开启串口接受中断
    USART_Cmd(USART3, ENABLE);                     //使能串口1
}

void NY8311_Send_Data(u8 *buf, u8 len)
{

    u8 t;

    for (t = 0; t < len; t++) //循环发送数据
    {
        while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET)
            vTaskDelay(1);
        USART_SendData(USART3, buf[t]);
        //printf("%02x\r\n", buf[t]);
    }

    while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET)
        vTaskDelay(1);

    RX3_CNT = 0;
}
// RS485查询接收到的数据
// buf:接收缓存首地址
// len:读到的数据长度
void NY8311_Receive_Data(u8 *buf, u8 *len)
{

    u8 rxlen = RX3_CNT;
    u8 i = 0;
    *len = 0;       //默认为0
    vTaskDelay(10); //等待10ms,连续超过10ms没有接收到一个数据,则认为接收结束

    if (rxlen == RX3_CNT && rxlen) //接收到了数据,且接收完成了
    {

        for (i = 0; i < rxlen; i++)
        {
            buf[i] = RX3_BUF[i];
            //printf("%02x\r\n", buf[i]);
        }
        *len = RX3_CNT; //记录本次数据长度

        RX3_CNT = 0; //清零
    }
}
u8 modbus_send[8] = {0x01, 0x03, 0x07, 0xD0, 0x00, 0x02, 0xBC, 0x54};
u8 modbus_receive[8];
u8 len;
u32 get_power(void)
{

    u32 power;
    NY8311_Send_Data(modbus_send, 8);
    vTaskDelay(200);
    NY8311_Receive_Data(modbus_receive, &len);

    power = modbus_receive[3] << 24 + modbus_receive[4] << 16 + modbus_receive[5] << 8 + modbus_receive[6];
    return power;
}