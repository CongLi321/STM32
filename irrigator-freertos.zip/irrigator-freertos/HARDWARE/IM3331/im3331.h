#ifndef __IM3331_H
#define __IM3331_H	
#include "sys.h"

u32 get_power(void);
void NY8311_Receive_Data(u8 *buf, u8 *len);
void NY8311_Send_Data(u8 *buf, u8 len);
void uart3_init(u32 bound);
void USART3_IRQHandler(void);
extern u32 now_power;
#endif
