#include "lcd12864.h"
#include "sys.h"
#include "usart.h"
#include "delay.h"
#include "FreeRTOS.h"
#include "task.h"

/* 字符显示RAM地址    4行8列 */
u8 LCD_addr[4][8] = {
	{0x80, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87}, //第一行
	{0x90, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97}, //第二行
	{0x88, 0x89, 0x8A, 0x8B, 0x8C, 0x8D, 0x8E, 0x8F}, //第三行
	{0x98, 0x99, 0x9A, 0x9B, 0x9C, 0x9D, 0x9E, 0x9F}  //第四行
};

void LCD12864_UserConfig(void)
{

	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	GPIO_InitStructure.GPIO_Pin = CS | SID | CLK | PSB;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;

	GPIO_Init(GPIO_LCD, &GPIO_InitStructure);
}

//发送一个字节
void LCD12864_Write_Byte(u8 dat)
{
	LCDCS_HIGH;
	for (int i = 0; i < 8; i++)
	{
		if ((dat << i) & 0x80)
			LCDSID_HIGH;
		else
			LCDSID_LOW;
		LCDCLK_LOW;

		LCDCLK_HIGH;
	}

	LCDCS_LOW;
}

void LCD12864_Write_Cmd_Data(u8 write_type, u8 data)
{
	LCD12864_Write_Byte(write_type);
	LCD12864_Write_Byte(data & 0xf0);
	LCD12864_Write_Byte((data << 4) & 0xf0);
	vTaskDelay(1);
}

//系统极其稳定，所有代码不要随意修改[手动狗头]
void LCD12864_Write_Init(void)
{
	LCDPSB_LOW;
	LCD12864_Write_Cmd_Data(CMD, 0x30);
	vTaskDelay(1);
	LCD12864_Write_Cmd_Data(CMD, 0x30);
	vTaskDelay(1);
	LCD12864_Write_Cmd_Data(CMD, 0x30);
	vTaskDelay(1);
	LCD12864_Write_Cmd_Data(CMD, 0x06);

	LCD12864_Write_Cmd_Data(CMD, 0x0C);

	LCD12864_Write_Cmd_Data(CMD, 0x01);

	LCD12864_Write_Cmd_Data(CMD, 0x80);
}

/*!
 *  @brief      显示字符或汉字
 *  @since      v1.0
 *  @param  x: row(0~3)
 *  @param  y: line(0~7)
 *  @param 	str: 要显示的字符或汉字
 */
void LCD_Display_Words(uint8_t x, uint8_t y, uint8_t *str)
{
	LCD12864_Write_Cmd_Data(CMD, LCD_addr[x][y]); //写初始光标位置
	while (*str > 0)
	{
		LCD12864_Write_Cmd_Data(DATA,*str); //写数据
		str++;
	}
}

void LCD12864_Write_Number(u8 com, u16 num)
{
	u8 number[] = {"0123456789"};
	LCD12864_Write_Cmd_Data(DATA, number[num / 1000]);
	LCD12864_Write_Cmd_Data(DATA, number[num % 1000 / 100]);
	LCD12864_Write_Cmd_Data(DATA, number[num % 100 / 10]);
	LCD12864_Write_Cmd_Data(DATA, number[num % 100 % 10]);
}
/*! 
 *  @brief      显示图片
 *  @since      v1.0
 *  @param  *pic   图片地址
 *  @author     
 */
//void LCD_Display_Picture(uint8_t *img)
//	{
//		uint8_t x,y,i;
//		Lcd_WriteCmd(0x34);		//切换到扩充指令
//		Lcd_WriteCmd(0x34);		//关闭图形显示
//		for(i = 0; i < 1; i++)   //上下屏写入
//		{
//			for(y=0;y<32;y++)   //垂直Y写32次
//			{  
//				for(x=0;x<8;x++)   //横向X写8次
//				{
//					Lcd_WriteCmd(0x80 + y);		//行地址
//					Lcd_WriteCmd(0x80 + x+i);		//列地址
//					Lcd_WriteData(*img ++);		//写高位字节数据 D15－D8   
//					Lcd_WriteData(*img ++);		//写低位字节数据 D7－D0
//				}
//			}
//		}
//		Lcd_WriteCmd(0x36);//打开图形显示		
//		Lcd_WriteCmd(0x30);        //切换回基本指令
//	}	
