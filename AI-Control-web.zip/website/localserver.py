from flask import Flask, send_file,render_template, request, redirect, url_for, jsonify
from pymongo import MongoClient
from bson import ObjectId
import gridfs
from flask import Response
import os
import openai
import base64
import cv2
import numpy as np
from ultralytics import YOLO


clientai = openai.OpenAI(api_key="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")
from werkzeug.utils import secure_filename
# Initialize Flask app
app = Flask(__name__)

# Mongo URI connection string
MongoURI = "mongodb+srv://licongnba:Liapple6s@cluster0.gw9ng.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"

# Connect to the MongoDB database
client = MongoClient(MongoURI)

# Access the collections
collection = client.database1.environmentdata
status_collection = client.database1.status
client = MongoClient(MongoURI)
db = client.img  # Ensure this is the correct database
fs = gridfs.GridFS(db)


# Route to display the index page
@app.route('/')
def index():
    # Get the latest 5 sensor data entries
    sensor_data = collection.find().sort("timestamp", -1).limit(5)
    data = list(sensor_data)
    
    # Get the current statuses of watering and LED
    status = status_collection.find_one({}, {'watering': 1, 'led': 1, '_id': 0})
    if not status:
        status = {'watering': 'OFF', 'led': 'OFF'}  # Default status if not found

    return render_template('index.html', data=data, status=status)





# Route to update status (watering or LED)

@app.route('/update_status', methods=['POST'])
def update_status():
    status_type = request.form.get('status_type')
    new_status = request.form.get('status_value')
    
    if status_type in ['watering', 'led']:
        # Update the status in MongoDB
        status_collection.update_one({}, {'$set': {status_type: new_status}}, upsert=True)
    
    return redirect(url_for('index'))

# API route to get the latest sensor data
@app.route('/api/sensor_data', methods=['GET'])
def get_sensor_data():
    # Fetch the latest 5 sensor data entries
    sensor_data = collection.find().sort("timestamp", -1).limit(5)
    data = list(sensor_data)
    
    if data:
        return jsonify({'status': 'success', 'data': data}), 200
    else:
        return jsonify({'status': 'error', 'message': 'No data found'}), 404

# API route to get statuses
@app.route('/api/status', methods=['GET'])
def get_status():
    status = status_collection.find_one({}, {'watering': 1, 'led': 1, '_id': 0})
    if status:
        return jsonify({'status': 'success', 'data': status}), 200
    else:
        return jsonify({'status': 'error', 'message': 'No data found'}), 404
    

    # API route to get statuses
@app.route('/api/updatacontrol', methods=['POST'])
def updatacontrol():
   if request.method == "POST":
        # Get form data
        watering_start = request.form["watering_start"]
        watering_end = request.form["watering_end"]
        led_start = request.form["led_start"]
        led_end = request.form["led_end"]
        print(watering_start)
        # Prepare the schedule data to insert into MongoDB
        schedule_data = {
            "watering_time": {"start": watering_start, "end": watering_end},
            "led_time": {"start": led_start, "end": led_end}
        }
        document_id = ObjectId("6740c4ffc91b0c2b29a83da8")
        # Insert the new schedule into the MongoDB collection
        status_collection.replace_one({"_id": document_id},schedule_data)

        # Redirect to the main page to show updated data
        return redirect(url_for('auto_control'))

@app.route('/auto_control.html',methods=['GET', 'POST'])
def auto_control():
   
    document_id = ObjectId("6740c4ffc91b0c2b29a83da8")  # Replace with your actual ObjectId
    schedules = status_collection.find_one({"_id": document_id})
  
# Print the retrieved document
  
    
    # # Query MongoDB to get all schedules
    # schedules = status_collection.find_one({"_id": document_id}, {'watering_time': 1, 'led_time': 1, '_id': 0})
   
    # # Pass the schedules to the template
    return render_template("auto_control.html", schedules=schedules)
@app.route('/image/<file_id>')
def get_image(file_id):
    try:
        file = fs.get(ObjectId(file_id))  # Retrieve file by ObjectId
    
       
        return Response(file.read(), mimetype='image/jpeg')  # Return the image as response
    except gridfs.errors.NoFile:
        return "❌ File not found", 404  # Handle case when file is not found
    except gridfs.errors.CorruptGridFile:
        return "❌ File is corrupted", 500  # Handle corrupted file error

@app.route('/images.html', methods=['GET', 'POST'])
def images():
    # Fetch all image files (using a query on the GridFS collection)
    files = fs.find()
    
    # Get the file IDs and filenames, combined into a list of tuples
    file_data = [(str(file._id), file.filename) for file in files]
    file_data = list(file_data)[-5:]
    file_data.reverse()
    # Pass the combined file data to the template
    return render_template('images.html', file_data=file_data)

# Configure upload folder
UPLOAD_FOLDER = r"C:\Users\Student\Downloads"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def encode_image(image_path):
    """Encodes an image in Base64 format for OpenAI API."""
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode("utf-8")

def analyze_plant_health(image_path):
    """Uses OpenAI's Vision API to analyze plant health."""
    encoded_image = encode_image(image_path)

    response = clientai.chat.completions.create(
        model="gpt-4-turbo",
        messages=[
            {"role": "system", "content": "You are an AI that analyzes plant images and provides care suggestions."},
            {"role": "user", "content": [
                {"type": "text", "text": "Count the number of main green plants (seedlings) in this image.how healthy are they?should i water them more or should i turn on the led more time?"},
                {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{encoded_image}"}}
            ]}
        ],
        max_tokens=500
    )
  
    return response.choices[0].message.content 


@app.route("/planthealth", methods=["GET", "POST"])
def plant_health():
    """Handles image uploads and displays AI analysis results."""
    if request.method == "POST":
        if "file" not in request.files:
            return render_template("planthealth.html", error="No file uploaded.")

        file = request.files["file"]
        if file.filename == "":
            return render_template("planthealth.html", error="No selected file.")
     
        # Save uploaded file
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        
    
        # Analyze plant health
        analysis_result = analyze_plant_health(filepath)
        
        return render_template("planthealth.html", image_url=filename, result=analysis_result)

    return render_template("planthealth.html")



# Path to your image folder
IMAGE_FOLDER = r"C:\Users\Student\Downloads"

@app.route('/local-image/<filename>')
def local_image(filename):
    """Dynamically serve images from the Downloads folder."""
    image_path = os.path.join(IMAGE_FOLDER, filename)
    
    # Ensure the file exists before serving
    if os.path.exists(image_path):
        return send_file(image_path, mimetype='image/jpeg')
    else:
        return "Image not found", 404



if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)



